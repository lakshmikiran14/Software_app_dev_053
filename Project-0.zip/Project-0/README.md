#Project - 0

The webpage is a sketch blog. I've made a blog for my sketches and included all the specifications mention in the project-0 requirements.

